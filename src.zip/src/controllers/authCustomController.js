const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const pool = require('../config/db');
const { generateAccessToken, generateRefreshToken, JWT_REFRESH_SECRET } = require('../middleware/authCustom');

const SALT_ROUNDS = 10;

// Génère un alanyaPhone unique à 6 chiffres
const generateAlanyaPhone = async () => {
  let alanyaPhone;
  let attempts = 0;
  while (attempts < 20) {
    alanyaPhone = Math.floor(100000 + Math.random() * 900000).toString();
    const [existing] = await pool.execute(
      'SELECT alanyaID FROM users WHERE alanyaPhone = ?',
      [alanyaPhone]
    );
    if (existing.length === 0) return alanyaPhone;
    attempts++;
  }
  throw new Error('Unable to generate unique phone number');
};

// ── REGISTER ─────────────────────────────────────────────────────────
const register = async (req, res) => {
  try {
    const { email, password, nom, pseudo, idPays, fcm_token, device_ID } = req.body;

    if (!email || !password) {
      return res.status(400).json({ error: 'Email and password required' });
    }

    if (password.length < 6) {
      return res.status(400).json({ error: 'Password must be at least 6 characters' });
    }

    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(email)) {
      return res.status(400).json({ error: 'Invalid email format' });
    }

    const [existingEmail] = await pool.execute(
      'SELECT alanyaID FROM users WHERE email = ?',
      [email.toLowerCase().trim()]
    );
    if (existingEmail.length > 0) {
      return res.status(409).json({ error: 'Email already in use' });
    }

    const alanyaPhone = await generateAlanyaPhone();
    const hashedPassword = await bcrypt.hash(password, SALT_ROUNDS);

    const [result] = await pool.execute(
      `INSERT INTO users
        (nom, pseudo, alanyaPhone, email, password, idPays, avatar_url,
         fcm_token, device_ID, last_seen, created_at)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, NOW(), NOW())`,
      [
        nom        || 'Utilisateur',
        pseudo     || nom || 'Kamite',
        alanyaPhone,
        email.toLowerCase().trim(),
        hashedPassword,
        idPays     || 1,
        'NON DEFINI',
        fcm_token  || 'INDEFINI',
        device_ID  || 'INDEFINI',
      ]
    );

    const tokenPayload  = { alanyaID: result.insertId, email: email.toLowerCase().trim() };
    const accessToken   = generateAccessToken(tokenPayload);
    const refreshToken  = generateRefreshToken(tokenPayload);

    const [rows] = await pool.execute(
      'SELECT alanyaID, nom, pseudo, alanyaPhone, email, avatar_url, is_online, last_seen FROM users WHERE alanyaID = ?',
      [result.insertId]
    );

    res.status(201).json({ user: rows[0], accessToken, refreshToken });
  } catch (error) {
    console.error('[Register] ERROR:', error);
    res.status(500).json({ error: error.message || 'Registration failed' });
  }
};

// ── LOGIN ─────────────────────────────────────────────────────────────
const login = async (req, res) => {
  try {
    const { alanyaPhone, password, fcm_token, device_ID } = req.body;

    if (!alanyaPhone || !password) {
      return res.status(400).json({ error: 'alanyaPhone and password required' });
    }

    const [rows] = await pool.execute(
      'SELECT alanyaID, nom, pseudo, alanyaPhone, email, password, avatar_url, is_online, exclus FROM users WHERE alanyaPhone = ?',
      [alanyaPhone]
    );

    if (rows.length === 0) {
      return res.status(401).json({ error: 'Invalid credentials' });
    }

    const user = rows[0];

    if (user.exclus === 1) {
      return res.status(403).json({ error: 'Account banned' });
    }

    const validPassword = await bcrypt.compare(password, user.password);
    if (!validPassword) {
      return res.status(401).json({ error: 'Invalid credentials' });
    }

    // Mettre à jour fcm_token et device_ID si fournis
    if (fcm_token || device_ID) {
      const updates = [];
      const values  = [];
      if (fcm_token) { updates.push('fcm_token = ?'); values.push(fcm_token); }
      if (device_ID) { updates.push('device_ID = ?'); values.push(device_ID); }
      values.push(user.alanyaID);
      await pool.execute(`UPDATE users SET ${updates.join(', ')} WHERE alanyaID = ?`, values);
    }

    const tokenPayload = { alanyaID: user.alanyaID, email: user.email };
    const accessToken  = generateAccessToken(tokenPayload);
    const refreshToken = generateRefreshToken(tokenPayload);

    delete user.password;
    delete user.exclus;
    res.json({ user, accessToken, refreshToken });
  } catch (error) {
    console.error('[Login] ERROR:', error);
    res.status(500).json({ error: error.message || 'Login failed' });
  }
};

// ── REFRESH TOKEN ─────────────────────────────────────────────────────
const refreshToken = async (req, res) => {
  try {
    const { refreshToken: token } = req.body;

    if (!token) {
      return res.status(400).json({ error: 'refreshToken required' });
    }

    let decoded;
    try {
      decoded = jwt.verify(token, JWT_REFRESH_SECRET);
    } catch (err) {
      if (err.name === 'TokenExpiredError') {
        return res.status(401).json({ error: 'Refresh token expired, please login again', code: 'REFRESH_EXPIRED' });
      }
      return res.status(401).json({ error: 'Invalid refresh token' });
    }

    if (decoded.type !== 'refresh') {
      return res.status(401).json({ error: 'Invalid token type' });
    }

    // Vérifier que le user existe toujours et n'est pas banni
    const [rows] = await pool.execute(
      'SELECT alanyaID, email FROM users WHERE alanyaID = ? AND exclus = 0',
      [decoded.alanyaID]
    );

    if (rows.length === 0) {
      return res.status(401).json({ error: 'User not found or banned' });
    }

    const tokenPayload    = { alanyaID: rows[0].alanyaID, email: rows[0].email };
    const newAccessToken  = generateAccessToken(tokenPayload);
    const newRefreshToken = generateRefreshToken(tokenPayload);

    res.json({ accessToken: newAccessToken, refreshToken: newRefreshToken });
  } catch (error) {
    console.error('[RefreshToken] ERROR:', error);
    res.status(500).json({ error: 'Token refresh failed' });
  }
};

// ── GENERATE OTP ──────────────────────────────────────────────────────
const generateOTP = () => {
  return Math.floor(100000 + Math.random() * 900000).toString();
};

const sendPasswordResetOTP = async (email, otp) => {
  const fromEmail =process.env.SMTP_FROM ;
  const fromName = process.env.MAIL_FROM_NAME || 'Alanya';
  const subject = 'Alanya password reset OTP';
  const text = `Your Alanya password reset OTP is ${otp}. It expires in 10 minutes. `;
  const html = `
    <p>Your Alanya password reset OTP is:</p>
    <p>Votre code OTP pour réinitialiser le mot de passe Alanya est:</p>
    <p style="font-size:24px;font-weight:700;letter-spacing:4px;">${otp}</p>
    <p>This code expires in 10 minutes.</p>
    <p>Ce code expire dans 10 minutes.</p>
  `;

  if (!fromEmail) {
    throw new Error('Email sender is not configured');
  }

  if (!process.env.SMTP_HOST) {
    throw new Error('Email service is not configured');
  }

  let nodemailer;
  try {
    nodemailer = require('nodemailer');
  } catch (error) {
    throw new Error('Nodemailer is required for SMTP email sending');
  }

  const transporter = nodemailer.createTransport({
    host: process.env.SMTP_HOST,
    port: Number(process.env.SMTP_PORT || 587),
    secure: process.env.SMTP_SECURE === 'true',
    auth: process.env.SMTP_USER && process.env.SMTP_PASS
      ? { user: process.env.SMTP_USER, pass: process.env.SMTP_PASS }
      : undefined,
  });

  await transporter.sendMail({
    from: `"${fromName}" <${fromEmail}>`,
    to: email,
    subject,
    text,
    html,
  });
};

// ── REQUEST PASSWORD RESET (Étape 1) ──────────────────────────────────
// Envoie un OTP à l'email
const requestPasswordReset = async (req, res) => {
  try {
    const { email } = req.body;

    if (!email) {
      return res.status(400).json({ error: 'Email required' });
    }

    const [rows] = await pool.execute(
      'SELECT alanyaID FROM users WHERE email = ?',
      [email.toLowerCase().trim()]
    );

    // Réponse volontairement vague pour éviter l'énumération
    if (rows.length === 0) {
      return res.json({ message: 'If this email exists, check your inbox for the OTP' });
    }

    const otp = generateOTP();
    const expiresAt = new Date(Date.now() + 10 * 60 * 1000); // OTP valide 10 minutes

    await pool.execute(
      'UPDATE users SET reset_otp = ?, reset_otp_expires_at = ? WHERE alanyaID = ?',
      [otp, expiresAt, rows[0].alanyaID]
    );

    await sendPasswordResetOTP(email.toLowerCase().trim(), otp);

    res.json({ message: 'If this email exists, check your inbox for the OTP' });
  } catch (error) {
    console.error('[RequestPasswordReset] ERROR:', error);
    res.status(500).json({ error: error.message || 'Request failed' });
  }
};

// ── VALIDATE OTP (Étape 2) ────────────────────────────────────────────
// Vérifie l'OTP et retourne un token temporaire
const validateOTP = async (req, res) => {
  try {
    const { email, otp } = req.body;

    if (!email || !otp) {
      return res.status(400).json({ error: 'Email and OTP required' });
    }

    const [rows] = await pool.execute(
      'SELECT alanyaID, reset_otp, reset_otp_expires_at FROM users WHERE email = ?',
      [email.toLowerCase().trim()]
    );

    if (rows.length === 0) {
      return res.status(401).json({ error: 'Invalid email' });
    }

    const user = rows[0];

    // Vérifier que l'OTP existe et est valide
    if (!user.reset_otp) {
      return res.status(400).json({ error: 'No OTP requested' });
    }

    if (user.reset_otp !== otp) {
      return res.status(401).json({ error: 'Invalid OTP' });
    }

    if (new Date() > new Date(user.reset_otp_expires_at)) {
      return res.status(401).json({ error: 'OTP expired' });
    }

    // Générer un token temporaire valide 15 minutes pour changer le mot de passe
    const resetToken = jwt.sign(
      { alanyaID: user.alanyaID, type: 'password_reset' },
      process.env.JWT_SECRET || 'talky-secret-key-change-in-production',
      { expiresIn: '15m' }
    );

    res.json({ resetToken, message: 'OTP validated. Use resetToken to change password' });
  } catch (error) {
    console.error('[ValidateOTP] ERROR:', error);
    res.status(500).json({ error: error.message || 'Validation failed' });
  }
};

// ── COMPLETE PASSWORD RESET (Étape 3) ─────────────────────────────────
// Change le mot de passe avec le reset token
const completePasswordReset = async (req, res) => {
  try {
    const { resetToken, newPassword } = req.body;

    if (!resetToken || !newPassword) {
      return res.status(400).json({ error: 'Reset token and new password required' });
    }

    if (newPassword.length < 6) {
      return res.status(400).json({ error: 'Password must be at least 6 characters' });
    }

    // Vérifier le reset token
    let decoded;
    try {
      decoded = jwt.verify(
        resetToken,
        process.env.JWT_SECRET || 'talky-secret-key-change-in-production'
      );
    } catch (err) {
      return res.status(401).json({ error: 'Invalid or expired reset token' });
    }

    if (decoded.type !== 'password_reset') {
      return res.status(401).json({ error: 'Invalid token type' });
    }

    // Hacher le nouveau mot de passe
    const hashedPassword = await bcrypt.hash(newPassword, SALT_ROUNDS);

    // Mettre à jour le mot de passe et nettoyer l'OTP
    await pool.execute(
      'UPDATE users SET password = ?, reset_otp = NULL, reset_otp_expires_at = NULL WHERE alanyaID = ?',
      [hashedPassword, decoded.alanyaID]
    );

    res.json({ message: 'Password updated successfully' });
  } catch (error) {
    console.error('[CompletePasswordReset] ERROR:', error);
    res.status(500).json({ error: error.message || 'Reset failed' });
  }
};

// ── RESET PASSWORD (Legacy - kept for backward compatibility) ─────────
const resetPassword = async (req, res) => {
  try {
    const { email, newPassword } = req.body;

    if (!email || !newPassword) {
      return res.status(400).json({ error: 'Email and new Password required' });
    }

    if (newPassword.length < 6) {
      return res.status(400).json({ error: 'Password must be at least 6 characters' });
    }

    const [rows] = await pool.execute(
      'SELECT alanyaID FROM users WHERE email = ?',
      [email.toLowerCase().trim()]
    );

    if (rows.length === 0) {
      // Réponse volontairement vague pour éviter l'énumération
      return res.json({ message: 'If this email exists, password has been reset' });
    }

    const hashedPassword = await bcrypt.hash(newPassword, SALT_ROUNDS);
    await pool.execute(
      'UPDATE users SET password = ? WHERE alanyaID = ?',
      [hashedPassword, rows[0].alanyaID]
    );

    res.json({ message: 'Password updated successfully' });
  } catch (error) {
    console.error('[ResetPassword] ERROR:', error);
    res.status(500).json({ error: error.message || 'Reset password failed' });
  }
};

// ── GET ME ────────────────────────────────────────────────────────────
const getMe = async (req, res) => {
  try {
    const [rows] = await pool.execute(
      'SELECT alanyaID, nom, pseudo, alanyaPhone, email, idPays, avatar_url, type_compte, is_online, last_seen FROM users WHERE alanyaID = ?',
      [req.user.alanyaID]
    );

    if (rows.length === 0) {
      return res.status(404).json({ error: 'User not found' });
    }

    res.json(rows[0]);
  } catch (error) {
    console.error('[GetMe] ERROR:', error);
    res.status(500).json({ error: error.message });
  }
};

// ── UPDATE ME ─────────────────────────────────────────────────────────
const updateMe = async (req, res) => {
  try {
    const { nom, pseudo, avatar_url, fcm_token, device_ID, is_online } = req.body;
    const updates = [];
    const values  = [];

    if (nom)       { updates.push('nom = ?');        values.push(nom); }
    if (pseudo)    { updates.push('pseudo = ?');     values.push(pseudo); }
    if (avatar_url){ updates.push('avatar_url = ?'); values.push(avatar_url); }
    if (fcm_token) { updates.push('fcm_token = ?');  values.push(fcm_token); }
    if (device_ID) { updates.push('device_ID = ?');  values.push(device_ID); }
    if (is_online !== undefined) {
      updates.push('is_online = ?, last_seen = NOW()');
      values.push(is_online ? 1 : 0);
    }

    if (updates.length === 0) {
      return res.status(400).json({ error: 'No fields to update' });
    }

    values.push(req.user.alanyaID);
    await pool.execute(
      `UPDATE users SET ${updates.join(', ')} WHERE alanyaID = ?`,
      values
    );

    const [rows] = await pool.execute(
      'SELECT alanyaID, nom, pseudo, alanyaPhone, email, avatar_url, is_online FROM users WHERE alanyaID = ?',
      [req.user.alanyaID]
    );

    res.json(rows[0]);
  } catch (error) {
    console.error('[UpdateMe] ERROR:', error);
    res.status(500).json({ error: error.message });
  }
};

module.exports = {
  register,
  login,
  refreshToken,
  resetPassword,
  requestPasswordReset,
  validateOTP,
  completePasswordReset,
  getMe,
  updateMe,
  authCustom: require('../middleware/authCustom').authCustom,
};
